const express = require("express");
const mongoose = require("mongoose");

require("dotenv").config();

const { getBankRouter } = require("./routes/get-bank-route");
const { addBankRouter } = require("./routes/add-bank-route");

const { errorHandler } = require("./middlewares/error-handler");
const { NotFoundError } = require("./errors/not-found-error");
const {
  DatabaseConnectionError,
} = require("./errors/database-connection-error");

const app = express();

app.use(express.json());

app.use((req, res, next) => {
  req.rabbitChannel = channel;
  next();
});

app.use(addBankRouter);
app.use(getBankRouter);

app.use(async (req, res, next) => {
  next(new NotFoundError());
});

app.use(errorHandler);

const start = async () => {
  const PORT = 8002;

  try {
    await mongoose.connect("mongodb://localhost:27017/PLMS-Bank");
    console.log("Connected to MongoDB :]");
  } catch (err) {
    throw new DatabaseConnectionError();
  }

  app.listen(PORT, () => {
    console.log("Listening on port 8002");
  });
};

start();
